#!/bin/bash
x=0
while true;
do
let x=$x+1
done
