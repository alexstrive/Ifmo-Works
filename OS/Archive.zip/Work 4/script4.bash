#!/bin/bash
nice -n 8 ./script4dop.bash&
nice -n 0 ./script4dop.bash&
