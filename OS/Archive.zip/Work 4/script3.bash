#!/bin/bash
echo "*/5 * * * 2 script1.bash" | crontab
